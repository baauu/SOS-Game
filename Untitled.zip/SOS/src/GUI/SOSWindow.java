package GUI;
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.SwingConstants;

public class SOSWindow {

	private JFrame frmSosGame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SOSWindow window = new SOSWindow();
					window.frmSosGame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SOSWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSosGame = new JFrame();
		frmSosGame.setTitle("SOS Game");
		frmSosGame.setBounds(100, 100, 450, 300);
		frmSosGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSosGame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		frmSosGame.getContentPane().add(panel, BorderLayout.NORTH);
		
		JLabel lblNewLabel = new JLabel("Settings:");
		panel.add(lblNewLabel);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Simple");
		panel.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("General");
		panel.add(rdbtnNewRadioButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("Size:");
		panel.add(lblNewLabel_1);
		
		textField = new JTextField();
		panel.add(textField);
		textField.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		frmSosGame.getContentPane().add(panel_1, BorderLayout.WEST);
		panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.Y_AXIS));
		
		JLabel lblNewLabel_2 = new JLabel("Blue:");
		panel_1.add(lblNewLabel_2);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("S");
		panel_1.add(rdbtnNewRadioButton_2);
		
		JRadioButton rdbtnNewRadioButton_3 = new JRadioButton("O");
		panel_1.add(rdbtnNewRadioButton_3);
		
		JPanel panel_2 = new JPanel();
		frmSosGame.getContentPane().add(panel_2, BorderLayout.EAST);
		panel_2.setLayout(new BoxLayout(panel_2, BoxLayout.Y_AXIS));
		
		JLabel lblNewLabel_3 = new JLabel("Red:");
		panel_2.add(lblNewLabel_3);
		
		JRadioButton rdbtnNewRadioButton_4 = new JRadioButton("S");
		panel_2.add(rdbtnNewRadioButton_4);
		
		JRadioButton rdbtnNewRadioButton_5 = new JRadioButton("O");
		panel_2.add(rdbtnNewRadioButton_5);
		
		JPanel panel_3 = new JPanel();
		frmSosGame.getContentPane().add(panel_3, BorderLayout.CENTER);
	}
}
