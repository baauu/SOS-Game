package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class subTest {

	@Test
	void test() {
		JUnit test = new JUnit();
		int output = test.sub(3, 1);
		assertEquals(2, output); 
	}

}
