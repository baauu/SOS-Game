package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class addTest {

	@Test
	void test() {
		JUnit test = new JUnit();
		int output = test.add(1,3);
		assertEquals(4, output); 
	}

}
